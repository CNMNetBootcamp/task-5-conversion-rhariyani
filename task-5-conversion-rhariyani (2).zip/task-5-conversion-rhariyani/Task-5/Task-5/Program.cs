﻿using System;

namespace Task_5
{
    class Program
    {
        static void Main(string[] args)
        {

            double cups = 0.0;
            double quarts = 0.0;

            int choice = 0;
            //int option= 0 ;
            string Question = "Y";
            string tempnum = string.Empty;
            bool isNumeric = true;

            do
            {

            
            do while (choice < 2)
                {
                    do
                    {


                        Console.WriteLine("What do you want to do? 1.cups to quarts , 2.quarts to cups :");


                        tempnum = Console.ReadLine();
                        isNumeric = double.TryParse(tempnum, out double n);
                        if (isNumeric == false || double.Parse(tempnum) <= 0 || double.Parse(tempnum) > 2)
                        {
                            Console.WriteLine("Please enter a number between 1 and 2");
                            isNumeric = false;
                        }

                    } while (isNumeric == false || double.Parse(tempnum) <= 0 || double.Parse(tempnum) > 2);
                    choice = int.Parse(tempnum);

                   
                        if (choice == 1)

                        {
                            Console.WriteLine("Enter number of cups :");
                            cups = int.Parse(Console.ReadLine());

                            quarts = cups * 4;
                            Console.WriteLine("The conversion of cups to quarts is:" + quarts);
                        }

                        else
                        {
                            Console.WriteLine("Enter number of quarts :");
                            quarts = int.Parse(Console.ReadLine());
                            cups = quarts * 4;
                            Console.WriteLine("The coversion of quarts to cup is:" + cups);
                        }
                   
                Console.WriteLine("Do you want to Continue? Y or N");
                Question = Console.ReadLine();
            } while (Question == "Y");

        } while (choice != 2);

                }
           
            
 
            
        }
    }

            
            


            



                

        
    
        
    




            


        
   
