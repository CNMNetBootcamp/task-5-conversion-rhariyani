## Task 5 ##
### Conversion ###
Create a program that converts cups to quarts/gallons and quarts to cups. The program shall ask the user what they want to convert, provide appropriate messages and output the result. The user will be given an option to quit or convert another measurement.