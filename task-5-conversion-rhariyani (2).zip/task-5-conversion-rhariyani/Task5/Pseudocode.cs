

//set up

double cups = 0.0;
double quarts = 0.0;

int choice;
int option;
string Question = "Y";
////input
//do{

//"What do you want to do? 1.cups to quarts , 2.quarts to cups :"
//choice=int.Parse(Console.Readline());


//} While(option>=4)
//{
//    console.readline();
//}

//////process
//do{

////if (choice=1)
////    {
////    quarts=cups*4;
////    "The conversion of cups to quarts is:" + quarts;
////    }

////    else 
////    {
////    cups=quarts*4;
////    "The coversion of quarts to cup is:+ " cups;
////    }
////    
//    Console.WriteLine("Do you want to Continue? Y or N");
//                    Question = Console.ReadLine();

//                } while (Question != "N");
//                Console.ReadLine();
//            }
//        }

//    }


// I have all comments as program work still it give all error due to this page


